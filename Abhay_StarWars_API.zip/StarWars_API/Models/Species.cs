﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace StarWars_API.Models
{
    public partial class Species
    {
        public Species()
        {
            FilmsSpecies = new HashSet<FilmsSpecies>();
            SpeciesPeople = new HashSet<SpeciesPeople>();
        }

        [Key]
        public int Id { get; set; }
        public string Average_Height { get; set; }
        public string Average_Lifespan { get; set; }
        public string Classification { get; set; }
        public DateTime? Created { get; set; }
        public string Designation { get; set; }
        public DateTime? Edited { get; set; }
        public string Eye_Colors { get; set; }
        public string Hair_Colors { get; set; }
        public int? Homeworld { get; set; }
        public string Language { get; set; }
        public string Name { get; set; }
        public string Skin_Colors { get; set; }

        public virtual ICollection<FilmsSpecies> FilmsSpecies { get; set; }
        public virtual ICollection<SpeciesPeople> SpeciesPeople { get; set; }
    }
}
