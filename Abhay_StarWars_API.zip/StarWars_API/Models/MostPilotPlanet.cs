﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace StarWars_API.Models
{
    public class MostPilotPlanet
    {
        public MostPilotPlanet()
        {
        }

        [Key]
        public string PilotName { get; set; }
        public string PlanetName { get; set; }
        public int PilotId { get; set; }
        public string SpeciesName { get; set; }
    }
}
