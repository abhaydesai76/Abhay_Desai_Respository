﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StarWars_API.Data;
using StarWars_API.Models;

namespace StarWars_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Produces("application/json")]
    public class FilmsController : ControllerBase
    {
        private readonly StarWars_APIContext _context;

        public FilmsController(StarWars_APIContext context)
        {
            _context = context;
        }

        [Route("GetLongestCrawlFilm")]
        [HttpGet]
        [Produces("application/json")]
  
        public ActionResult<string> GetLongestCrawlFilm()
        {
            List<Film> flmslist = new List<Film>();

            flmslist = _context.Film.ToList();

            if (flmslist != null)
            {
                Film filmwithlongestcrawl = flmslist.OrderByDescending(fl => (fl.Opening_Crawl.Length)).ToList().FirstOrDefault();

                return filmwithlongestcrawl.Title;
            }
            else
            {
                return null;
            }
        }

        [Route("GetMaximumCharacterAppearance")]
        [HttpGet]
        [Produces("application/json")]
        
        public IEnumerable<CharacterMaximumAppearance> GetMaximumCharacterAppearance()
        {
            var result = (from filmcharacters in _context.FilmsCharacters
                          join people in _context.People on filmcharacters.People_Id equals people.Id
                          join Film in _context.Film on filmcharacters.Film_Id equals Film.Id
                          orderby people.Id
                          //group people by people.Name

                          select new CharacterMaximumAppearance { PeopleId = people.Id, CharacterName = filmcharacters.People.Name, CharacterId = filmcharacters.People_Id });

            return result;

        }

        [Route("GetSpeciesMaximumAppearance")]
        [HttpGet]
        [Produces("application/json")]
        
        public IEnumerable<SpeciesMaximumAppearance> GetSpeciesMaximumAppearance()
        {
            var result = (from filmcharacters in _context.FilmsCharacters
                          join people in _context.People on filmcharacters.People_Id equals people.Id
                          join speciespeople in _context.SpeciesPeople on people.Id equals speciespeople.People_Id
                          join species in _context.Species on speciespeople.Species_Id equals species.Id
                          orderby people.Id
                          //group s by s.Name into g

                          select new SpeciesMaximumAppearance { PeopleId = people.Id, Name = filmcharacters.People.Name, Apperances = filmcharacters.People_Id });            

            return result;
        }

        [Route("GetMostPilotsPlanet")]
        [HttpGet]
        [Produces("application/json")]
        public IEnumerable<MostPilotPlanet> GetMostPilotsPlanet()
        {
            var result = (from vehiclespilots in _context.VehiclesPilots
                         join people in _context.People on vehiclespilots.People_Id equals people.Id
                         join planets in _context.Planets on people.Homeworld equals planets.Id
                         join species in _context.Species on people.Homeworld equals species.Homeworld into peoplelantvehiclepilotsspecies
                         from resultvalues in peoplelantvehiclepilotsspecies.DefaultIfEmpty()
                          orderby people.Id

                          select new MostPilotPlanet { PilotId = people.Id, PilotName = people.Name, PlanetName = planets.Name, SpeciesName = (resultvalues.Name == null ? "Human" : resultvalues.Name) });            

            return result;
        }        
    }
}
