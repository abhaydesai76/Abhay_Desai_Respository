﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace StarWars_API.Models
{
    public partial class Starships
    {
        public Starships()
        {
            FilmsStarships = new HashSet<FilmsStarships>();
            StarshipsPilots = new HashSet<StarshipsPilots>();
        }

        [Key]
        public int Id { get; set; }
        public string Mglt { get; set; }
        public string Hyperdrive_Rating { get; set; }
        public string Starship_Class { get; set; }

        public virtual ICollection<FilmsStarships> FilmsStarships { get; set; }
        public virtual ICollection<StarshipsPilots> StarshipsPilots { get; set; }
    }
}
