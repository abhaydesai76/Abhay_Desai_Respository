﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace StarWars_API.Models
{
    public partial class Vehicles
    {
        public Vehicles()
        {
            FilmsVehicles = new HashSet<FilmsVehicles>();
            VehiclesPilots = new HashSet<VehiclesPilots>();
        }

        [Key]
        public int Id { get; set; }
        public string Vehicle_Class { get; set; }

        public virtual ICollection<FilmsVehicles> FilmsVehicles { get; set; }
        public virtual ICollection<VehiclesPilots> VehiclesPilots { get; set; }
    }
}
