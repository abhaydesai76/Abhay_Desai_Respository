﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StarWars_API.Models
{
    public class VehiclePilotsSpecies
    {
        public string PlanetName { get; set; }
        public int NoOfPilots { get; set; }
        public string PilotNamesSpecieName { get; set; }

    
    }
}
