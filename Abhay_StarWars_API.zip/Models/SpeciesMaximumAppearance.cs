﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace StarWars_API.Models
{
    public class SpeciesMaximumAppearance
    {
        public SpeciesMaximumAppearance()
        {
        }

        [Key]
        public int PeopleId { get; set; }
        public string Name { get; set; }
        public int Apperances { get; set; }
    }
}
