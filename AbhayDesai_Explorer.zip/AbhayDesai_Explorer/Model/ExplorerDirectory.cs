﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbhayDesai_Explorer.Model
{
    public class ExplorerDirectory
    {
        private string m_directoryname;
        private string m_directorytype;
        private string m_datemodified;        
        private string m_datecreated;
        private string m_selecteddrive;

        public string DirectoryName
        {
            get { return m_directoryname; }
            set { m_directoryname = value; }
        }

        public string DirectoryType
        {
            get { return m_directorytype; }
            set { m_directorytype = value; }
        }
        public string DateCreated
        {
            get { return m_datecreated; }
            set { m_datecreated = value; }
        }

        public string DateModified
        {
            get { return m_datemodified; }
            set { m_datemodified = value; }
        }
        public string SelectedDrive
        {
            get { return m_selecteddrive; }
            set { m_selecteddrive = value; }
        }
        public ExplorerDirectory(string directoryname, string directorytype, string datemodified, string datecreated, string selecteddrive)
        {
            DirectoryName = directoryname;
            DirectoryType = directorytype;
            DateModified = datemodified;
            DateCreated = datecreated;
            SelectedDrive = selecteddrive;
        }
    }
}
