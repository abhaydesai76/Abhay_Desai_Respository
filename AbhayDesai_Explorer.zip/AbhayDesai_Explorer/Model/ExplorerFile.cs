﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbhayDesai_Explorer.Model
{
    public class ExplorerFile
    {
        private string m_filename;
        private string m_filetype;
        private string m_filemodified;        
        private string m_filecreated;        

        public string FileName
        {
            get { return m_filename; }
            set { m_filename = value; }
        }

        public string FileType
        {
            get { return m_filetype; }
            set { m_filetype = value; }
        }
        public string FileModified
        {
            get { return m_filemodified; }
            set { m_filemodified = value; }
        }

        public string FileCreated
        {
            get { return m_filecreated; }
            set { m_filecreated = value; }
        }        
        public ExplorerFile(string filename, string filetype, string filemodified, string filecreated)
        {
            FileName = filename;
            FileType = filetype;
            FileModified = filemodified;
            FileCreated = filecreated;            
        }
    }
}
