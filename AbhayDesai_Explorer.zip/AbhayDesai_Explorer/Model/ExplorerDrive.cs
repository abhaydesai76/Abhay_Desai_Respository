﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbhayDesai_Explorer.Model
{
    public class ExplorerDrive
    {
        private string m_drivename;
        private string m_drivetype;
        private long m_drivesize;
        private long m_numberofdrives;
        public string DriveName
        {
            get { return m_drivename; }
            set { m_drivename = value; }
        }

        public string DriveType
        {
            get { return m_drivetype; }
            set { m_drivetype = value; }
        }
        public long DriveSize
        {
            get { return m_drivesize; }
            set { m_drivesize = value; }
        }

        public long NumberofDrives
        {
            get { return m_numberofdrives; }
            set { m_numberofdrives = value; }
        }        
        public ExplorerDrive(string drivename, string drivetype, long drivesize, long numberofdrives)
        {
            DriveName = drivename;
            DriveType = drivetype;
            DriveSize = drivesize;
            NumberofDrives = numberofdrives;            
        }
    }
}
