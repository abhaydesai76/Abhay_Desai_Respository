﻿using AbhayDesai_Explorer.ViewModel;
using System.Windows;

namespace AbhayDesai_Explorer
{
    /// <summary>
    /// Interaction logic for Explorer.xaml
    /// </summary>
    public partial class Explorer: Window
    {
        private readonly DriveViewModel driveViewModel;

        public Explorer()
        {          
            InitializeComponent();

            App.Current.MainWindow.WindowState = WindowState.Maximized;

            driveViewModel = new DriveViewModel();

            DataContext = driveViewModel;
        }
    }
}
