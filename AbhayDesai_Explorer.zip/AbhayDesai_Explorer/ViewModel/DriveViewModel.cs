﻿using AbhayDesai_Explorer.Model;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Input;

namespace AbhayDesai_Explorer.ViewModel
{
    public class DriveViewModel : BaseViewModel
    {
        private ExplorerDrive drive;
        private List<ExplorerDrive> drives = new List<ExplorerDrive>();

        private List<ExplorerDirectory> directories = new List<ExplorerDirectory>();
        private DirectoryViewModel directoryViewModel;
        
        private List<ExplorerFile> files = new List<ExplorerFile>();
        private FileViewModel fileViewModel;

        private ICommand _GetDirectoriesSelectedDriveCommand;
        public string DriveName
        {
            get
            {
                return drive.DriveName;
            }
            set 
            { 
            if (drive.DriveName != null)
                {
                    drive.DriveName = value;
                    RaisePropertyChanged("DriveName");
                }
            }
        }

        public string DriveType
        {
            get
            {
                return drive.DriveType;
            }
            set
            {
                if (drive.DriveType != null)
                {
                    drive.DriveType = value;
                    RaisePropertyChanged("DriveType");
                }
            }
        }

        public long DriveSize
        {
            get
            {
                return drive.DriveSize;
            }
            set
            {
                if (drive.DriveSize != 0)
                {
                    drive.DriveSize = value;
                    RaisePropertyChanged("DriveSize");
                }
            }
        }       

        public ExplorerDrive Drive
        {
            get
            {
                return drive;
            }
            set
            {
                if (drive != null)
                {
                    drive = value;
                    RaisePropertyChanged("Drive");
                }
            }
        }

        public List<ExplorerDrive> Drives
        {
            get
            {
                return drives;
            }
            set
            {
                if (drives.Count != 0)
                {
                    drives = value;
                    RaisePropertyChanged("Drives");
                }
            }
        }
        public List<ExplorerDirectory> Directories
        {
            get
            {
                return directories;
            }
            set
            {
                if (directories.Count != 0)
                {
                    directories = value;
                    RaisePropertyChanged("Directories");
                }
            }
        }

        public List<ExplorerFile> Files
        {
            get
            {
                return files;
            }
            set
            {
                if (files.Count != 0)
                {
                    files = value;
                    RaisePropertyChanged("Files");
                }
            }
        }

        public ICommand GetDirectoriesSelectedDriveCommand
        {
            get
            {
                return _GetDirectoriesSelectedDriveCommand ?? (_GetDirectoriesSelectedDriveCommand = new 
                    RelayCommand(args => GetDirectoriesSelectedDrive(args)));                    
            }
            set
            {
                _GetDirectoriesSelectedDriveCommand = value;
                RaisePropertyChanged("SelectedDrive");
            }            
        }

        public DriveViewModel()
        {
            try
            {
                drive = new ExplorerDrive("C:\\", "Fixed", 500000, 1);

                drives = GetAllDrives();

                directoryViewModel = new DirectoryViewModel();
                directories = directoryViewModel.GetAllDirectories("C:\\");

                fileViewModel = new FileViewModel();
                files = fileViewModel.GetAllFiles("C:\\");
            }
            catch (System.Exception ex)
            {
                // write to a log file OR into a database table as per project requirement              
            }
            finally
            {
                // do the required cleanup if any
            }
        }

        public DirectoryViewModel DirectoryViewModel
        {
            get
            {
                return directoryViewModel;
            }
            set
            {
                directoryViewModel = value;
                RaisePropertyChanged("DirectoryViewModel");
            }
        }

        public List<ExplorerDrive> GetAllDrives()
        {            DriveInfo[] driveInfo = DriveInfo.GetDrives();
            int numberofdrives = 0;

            foreach (DriveInfo di in driveInfo)
            {
                if (di.IsReady == true)
                {
                    var data = new ExplorerDrive(di.Name, di.DriveType.ToString(), di.TotalSize, numberofdrives= numberofdrives+1);
                    Drives.Add(data);
                }
                else 
                { 
                    var data = new ExplorerDrive(di.Name, di.DriveType.ToString(), 100, numberofdrives = numberofdrives + 1);
                    Drives.Add(data);
                }
            }

            return Drives;
        }

        private List<ExplorerDirectory> GetDirectoriesSelectedDrive(object args)
        {
            try
            {
                var drive = args as ExplorerDrive;

                Directories = DirectoryViewModel.GetAllDirectories(drive.DriveName);

                return Directories;
            }
            catch (System.Exception ex)
            {
                // write to a log file OR into a database table as per project requirement
                return Directories;
            }
            finally
            {
                // do the required cleanup if any
            }
        }
    }
}
