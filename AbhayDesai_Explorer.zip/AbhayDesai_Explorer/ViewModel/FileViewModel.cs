﻿using AbhayDesai_Explorer.Model;
using System.Collections.Generic;
using System.IO;

namespace AbhayDesai_Explorer.ViewModel
{
    public class FileViewModel : BaseViewModel
    {
        private ExplorerFile file;
        private ExplorerDrive drive;
        private ExplorerDirectory directory;
        private List<ExplorerDirectory> directories = new List<ExplorerDirectory>();
        private List<ExplorerFile> files = new List<ExplorerFile>();

        public string FileName
        {
            get
            {
                return file.FileName;
            }
            set 
            { 
            if (file.FileName != null)
                {
                    file.FileName = value;
                    RaisePropertyChanged("FileName");
                }
            }
        }

        public string FileType
        {
            get
            {
                return file.FileType;
            }
            set
            {
                if (file.FileType != null)
                {
                    file.FileType = value;
                    RaisePropertyChanged("FileType");
                }
            }
        }

        public string SelectedDirectory
        {
            get
            {
                return directory.SelectedDrive;
            }
            set
            {
                if (directory.SelectedDrive != null)
                {
                    directory.SelectedDrive = value;
                    RaisePropertyChanged("SelectedDirectory");
                }
            }
        }

        public string FileCreated
        {
            get
            {
                return file.FileCreated;
            }
            set
            {
                if (file.FileCreated != null)
                {
                    file.FileCreated = value;
                    RaisePropertyChanged("FileCreated");
                }
            }
        }
        public string FileModified
        {
            get
            {
                return file.FileModified;
            }
            set
            {
                if (file.FileModified != null)
                {
                    file.FileModified = value;
                    RaisePropertyChanged("FileModified");
                }
            }
        }

        public ExplorerFile File
        {
            get
            {
                return file;
            }
            set
            {
                if (file != null)
                {
                    file = value;
                    RaisePropertyChanged("File");
                }
            }
        }

        public List<ExplorerFile> Files
        {
            get
            {
                return files;
            }
            set
            {
                if (files.Count != 0)
                {
                    files = value;
                    RaisePropertyChanged("Files");
                }
            }
        }

        public List<ExplorerDirectory> Directories
        {
            get
            {
                return directories;
            }
            set
            {
                if (directories.Count != 0)
                {
                    directories = value;
                    RaisePropertyChanged("Directories");
                }
            }
        }

        public FileViewModel()
        {

        }

        public List<ExplorerFile> GetAllFiles(string selecteddrivedirectory)
        {
            try
            {
                Files.Clear();

                DirectoryInfo dirfileinfo = new DirectoryInfo(selecteddrivedirectory);

                foreach (FileInfo fileinfo in dirfileinfo.GetFiles())
                {
                    var data = new ExplorerFile(fileinfo.Name, fileinfo.Attributes.ToString(), fileinfo.LastWriteTime.ToString(), fileinfo.CreationTime.ToString());

                    Files.Add(data);
                }

                return Files;
            }
            catch (System.Exception ex)
            {
                // write to a log file OR into a database table as per project requirement
                return Files;
            }
            finally
            {
                // do the required cleanup if any
            }
        }
    }
}
