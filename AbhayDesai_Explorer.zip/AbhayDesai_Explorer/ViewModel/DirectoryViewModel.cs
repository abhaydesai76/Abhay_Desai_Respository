﻿using AbhayDesai_Explorer.Model;
using System.Collections.Generic;
using System.IO;
using System.Windows.Input;

namespace AbhayDesai_Explorer.ViewModel
{
    public class DirectoryViewModel : BaseViewModel
    {
        private ExplorerDirectory directory;
        private ExplorerDrive drive;
        private List<ExplorerDirectory> directories = new List<ExplorerDirectory>();

        private ICommand _GetDirectoriesSelectedDirectoryCommand;
        public string DirectoryName
        {
            get
            {
                return directory.DirectoryName;
            }
            set 
            { 
            if (directory.DirectoryName != null)
                {
                    directory.DirectoryName = value;
                    RaisePropertyChanged("DirectoryName");
                }
            }
        }

        public string DirectoryType
        {
            get
            {
                return directory.DirectoryType;
            }
            set
            {
                if (directory.DirectoryType != null)
                {
                    directory.DirectoryType = value;
                    RaisePropertyChanged("DirectoryType");
                }
            }
        }

        public string SelectedDrive
        {
            get
            {
                return directory.SelectedDrive;
            }
            set
            {
                if (directory.SelectedDrive != null)
                {
                    directory.SelectedDrive = value;
                    RaisePropertyChanged("SelectedDrive");
                }
            }
        }

        public string DateCreated
        {
            get
            {
                return directory.DateCreated;
            }
            set
            {
                if (directory.DateCreated != null)
                {
                    directory.DateCreated = value;
                    RaisePropertyChanged("DateCreated");
                }
            }
        }
        public string DateModified
        {
            get
            {
                return directory.DateModified;
            }
            set
            {
                if (directory.DateModified != null)
                {
                    directory.DateModified = value;
                    RaisePropertyChanged("DateModified");
                }
            }
        }

        public ExplorerDirectory Directory
        {
            get
            {
                return directory;
            }
            set
            {
                if (directory != null)
                {
                    directory = value;
                    RaisePropertyChanged("Directory");
                }
            }
        }

        public List<ExplorerDirectory> Directories
        {
            get
            {
                return directories;
            }
            set
            {
                if (directories.Count != 0)
                {
                    directories = value;
                    RaisePropertyChanged("Directories");
                }
            }
        }
        public DirectoryViewModel()
        {

        }

        public ICommand GetDirectoriesSelectedDirectoryCommand
        {
            get
            {
                return _GetDirectoriesSelectedDirectoryCommand ?? (_GetDirectoriesSelectedDirectoryCommand = new
                    RelayCommand(args => GetAllDirectories(args.ToString())));
            }
            set
            {
                _GetDirectoriesSelectedDirectoryCommand = value;
                RaisePropertyChanged("SelectedDirectory");
            }
        }

        public List<ExplorerDirectory> GetAllDirectories(string selecteddrivedirectory)
        {
            try
            {
                Directories.Clear();

                DirectoryInfo dirinfo = new DirectoryInfo(selecteddrivedirectory);

                foreach (DirectoryInfo di in dirinfo.GetDirectories())
                {
                    var data = new ExplorerDirectory(di.Name, di.Attributes.ToString(), di.LastWriteTime.ToString(), di.CreationTime.ToString(), selecteddrivedirectory);

                    Directories.Add(data);
                }

                return Directories;
            }
            catch (System.Exception ex)
            {
                // write to a log file OR into a database table as per project requirement
                return Directories;
            }
            finally
            {
                // do the required cleanup if any
            }            
        }
    }
}
