﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RespositoryPattern_MVC.Models
{
    [Table("Employees")]
    public class Employees
    {
        [Key]
        public int EmployeeId
            {
                get;
                set;
            }

        [Display(Name = "Employee Name")]
        [Required(ErrorMessage ="Name is required")]
        public string EmployeeName
        {
            get;
            set;
        }

       [Display(Name ="Employee Addreess")]
       [Required(ErrorMessage ="Address is required")]
        public string Address
        {
            get;
            set;
        }

        [Required(ErrorMessage ="Email ID is required")]
        public string EmailID
        {
            get;
            set;
        }

        [Display(Name ="Mobile No")]
        [Required(ErrorMessage ="Mobile No is required")]
        public string Mobile
        {
            get;
            set;
        }
    }
}