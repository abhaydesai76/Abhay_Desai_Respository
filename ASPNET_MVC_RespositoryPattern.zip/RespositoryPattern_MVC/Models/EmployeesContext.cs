﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;

namespace RespositoryPattern_MVC.Models
{
    public class EmployeesContext : DbContext
    {
        public EmployeesContext() : base("DefaultConnection") { }

        public DbSet<Employees> Employees
        {
            get;
            set;
        }
    }
}