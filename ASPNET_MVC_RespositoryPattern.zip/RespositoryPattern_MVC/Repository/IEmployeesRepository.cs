﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RespositoryPattern_MVC.Models;

namespace RespositoryPattern_MVC.Repository
{
    public interface IEmployeesRepository : IDisposable
    {
        // Return a list of all employees
        IEnumerable<Employees> GetAllEmployees();

        // Retuen a specific employee as per EmployeeID
        Employees GetEmployeebyID(int employeeid);

        // Add a new employee and return result
        int AddEmployee(Employees employeesEntity);

        // Update an existing employee and return result
        int UpdateEmployee(Employees employeesEntity);

        // Delete a specific employee as per EmployeeID
        void DeleteEmployee(int employeeid);
    }
}