﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RespositoryPattern_MVC.Models;
using System.Data;
using System.Data.Entity;

namespace RespositoryPattern_MVC.Repository
{
    public class EmployeesRepository : IEmployeesRepository
    {

        private readonly EmployeesContext _context;
        private bool disposed = false;

        public EmployeesRepository(EmployeesContext context)
        {
            _context = context;
        }

        public IEnumerable<Employees> GetAllEmployees()
        {
            return _context.Employees.ToList();
        }

        public Employees GetEmployeebyID(int employeeID)
        {
            return _context.Employees.Find(employeeID);
        }

        public int AddEmployee(Employees employeesEntity)
        {
            int result = -1;

            if (employeesEntity != null)
            {
                _context.Employees.Add(employeesEntity);
                _context.SaveChanges();

                result = employeesEntity.EmployeeId;
            }

            return result;
        }

        public int UpdateEmployee(Employees employeesEntity)
        {
            int result = -1;

            if (employeesEntity != null)
            {
                _context.Entry(employeesEntity).State = EntityState.Modified;
                _context.SaveChanges();

                result = employeesEntity.EmployeeId;
            }

            return result;
        }

        public void DeleteEmployee(int employeeID)
        {
            Employees employeesEntity = _context.Employees.Find(employeeID);
            _context.Employees.Remove(employeesEntity);
            _context.SaveChanges();
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    _context.Dispose();
                }
            }

            this.disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);

            GC.SuppressFinalize(this);
        }
    }
}