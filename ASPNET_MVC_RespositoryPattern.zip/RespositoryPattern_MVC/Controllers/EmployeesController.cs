﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using RespositoryPattern_MVC.Models;
using RespositoryPattern_MVC.Repository;

namespace RespositoryPattern_MVC.Controllers
{
    public class EmployeesController : Controller
    {
        private IEmployeesRepository _employeesRepository;

        public EmployeesController()
        {
            _employeesRepository = new EmployeesRepository(new Models.EmployeesContext());
        }

        public EmployeesController(IEmployeesRepository employeesRepository)
        {
            _employeesRepository = employeesRepository;
        }

        // GET: Employees
        public ActionResult Index()
        {
            var model = _employeesRepository.GetAllEmployees();

            return View(model);
        }

        public ActionResult Details(int EmployeeID)
        {
            Employees model = _employeesRepository.GetEmployeebyID(EmployeeID);

            return View(model);
        }


        public ActionResult AddEmployee()
        {
            if (TempData["Failed"] != null)
            {
                ViewBag.Failed = "Add Employee Failed";
            }

            return View(); 
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AddEmployee(Employees model)
        {
            if (ModelState.IsValid)
            {
                int result = _employeesRepository.AddEmployee(model);

                if (result > 0)
                {
                    return RedirectToAction("Index", "Employees");
                }
                else
                {
                    TempData["Failed"] = "Failed";
                    return RedirectToAction("AddEmployee", "Employees");
                }
            }

            return View();
        }
     
        public ActionResult UpdateEmployee(int EmployeeID)
        {
            if (TempData["Failed"] != null)
            {
                ViewBag.Failed = "Edit Employee Failed";
            }

            Employees model = _employeesRepository.GetEmployeebyID(EmployeeID);

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UpdateEmployee(Employees model)
        {

            if (ModelState.IsValid)
            {
                int result = _employeesRepository.UpdateEmployee(model);

                if (result  > 0)
                {
                    return RedirectToAction("Index", "Employees");
                }
                else
                {
                    return RedirectToAction("UpdateEmployee", "Employees");
                }
            }
            return View();
        }

        public ActionResult DeleteEmployee(int EmployeeId)
        {
            Employees model = _employeesRepository.GetEmployeebyID(EmployeeId);

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteEmployee(Employees model)
        {
            if (TempData["Failed"] != null)
            {
                ViewBag.Failed = "Delete Employee Failed";
            }

            _employeesRepository.DeleteEmployee(model.EmployeeId);

            return RedirectToAction("Index", "Employees");
        }
    }
}
