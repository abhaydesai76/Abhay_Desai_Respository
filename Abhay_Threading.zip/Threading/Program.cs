﻿using System;
using System.Diagnostics;
using System.Threading;

namespace Threading
{
    class Program
    {
        private static int num1 = 0;
        private static int num2 = 0;

        private static Mutex mut = new Mutex();
        private const int numIterations = 1;
        private const int numThreads = 3;

        private static Semaphore _pool;
        private static int _padding;

        static void Main(string[] args)
        {
            _pool = new Semaphore(0, 3);

            for (int i = 1; i < 5; i++)
            {
                Thread t = new Thread(new ParameterizedThreadStart(Worker));

                t.Start(i);
            }

            Thread.Sleep(500);

            Console.WriteLine("Main thread calls Release(3)");
            _pool.Release(3);

            Console.WriteLine("Main thread exits");
            //for (int i =0; i < numThreads; i++)
            //{
            //    Thread newThread = new Thread(new ThreadStart(ThreadProc));
            //    newThread.Name = String.Format("Thread {0}", i+1);
            //    newThread.Start();
            //}

            //Method1();
            //Method2();

            //Thread objectThread1 = new Thread(Method1);
            //Thread objectThread2 = new Thread(Method2);

            //objectThread1.Start();
            //objectThread2.Start();

            //Thread objWorkerThread = new Thread(WorkerThread);            

            //for (int k=0; k < 10; k++)
            //{
            //    Console.WriteLine("Main Thread");
            //    Thread.Sleep(4000);
            //}

            //Thread objWorkerThread = new Thread(ProcessJoin);
            //objWorkerThread.Start();
            //objWorkerThread.Join();
            //Console.WriteLine("Work Completed !!!");

            //ThreadPool.QueueUserWorkItem(new WaitCallback(Run));
            //Console.ReadLine();

            //RunWithThreadPool();
            //RunWithoutThreadPool();

            //Stopwatch mywatch = new Stopwatch();

            //Console.WriteLine("Run with ThreadPool");

            //mywatch.Start();
            //RunWithThreadPool();
            //mywatch.Stop();

            //Console.WriteLine("Time consumed with Thread Pool is :" + mywatch.ElapsedMilliseconds) ;

            //mywatch.Reset();

            //Console.WriteLine("Run without ThreadPool");

            //mywatch.Start();
            //RunWithoutThreadPool();
            //mywatch.Stop();

            //Console.WriteLine("Time consumed witout Thread Pool is :" + mywatch.ElapsedMilliseconds;
        }

        static void Method1()
        {
            for (int i = 0; i <= 10; i++)
            {
                Console.WriteLine("Method 1 executed : " + i.ToString());

                Thread.Sleep(4000);
            }
        }
        static void Method2()
        {
            for (int i = 0; i <= 10; i++)
            {
                Console.WriteLine("Method 2 executed : " + i.ToString());

                Thread.Sleep(4000);
            }            
        }
        static void WorkerThread()
        {
            for (int i = 1; i < 10; i++)
            {
                Console.WriteLine("Worker Thread");
                Thread.Sleep(4000);
            }
        }

        static void ProcessJoin()
        {
            for (int i=0; i < 10; i++)
            {
                Console.WriteLine("Work is in progress ...");
            }
        }

        static void Run(object callback)
        {
            for (int i=0; i< 27; i++)
            {
                Console.WriteLine("Number :" + i);
                Thread.Sleep(250);
            }
        }

        static void TestThreadPool(object callback)
        {

        }

        static void RunWithThreadPool()
        {
            for (int i =0; i <+ 10; i++)
            {
                ThreadPool.QueueUserWorkItem(new WaitCallback(TestThreadPool));
            }
        }

        static void RunWithoutThreadPool()
        {
            for (int j=0; j <= 10; j++)
            {
                Thread obj = new Thread(TestThreadPool);
                obj.Start();
            }
        }
        private static void ThreadProc()
        {
            for (int i = 0; i < numIterations; i++)
            {
                UseResource();
            }
        }

        private static void UseResource()
        {
            Console.WriteLine("{0} is requesting the Mutex", Thread.CurrentThread.Name);

            mut.WaitOne();

            Console.WriteLine("{0} has entered the protected area", Thread.CurrentThread.Name);

            Thread.Sleep(500);

            Console.WriteLine("{0} is leaving the protected area", Thread.CurrentThread.Name);

            mut.ReleaseMutex();

            Console.WriteLine("{0} has released the Mutex", Thread.CurrentThread.Name);
        } 

        private static void Worker(object num)
        {
            Console.WriteLine("Thread {0} begins and waits for the semaphore", num);
            _pool.WaitOne();

            int padding = Interlocked.Add(ref _padding, 100);

            Console.WriteLine("Thread {0} enters the semaphore" , num);

            Thread.Sleep(1000 + padding);

            Console.WriteLine("Thread {0} realease the semaphore", num);
            Console.WriteLine("Thead {0} previous semaphore count : {1}", num, _pool.Release());

        }
    }
}
